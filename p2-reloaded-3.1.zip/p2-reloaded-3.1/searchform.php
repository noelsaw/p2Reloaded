						<form action="<?php bloginfo('siteurl') ?>" method="get">
							<input type="text" name="s" value="" placeholder="Search here..." size="15"> 
							<input type="submit" name="submit" value="Search">
						</form>