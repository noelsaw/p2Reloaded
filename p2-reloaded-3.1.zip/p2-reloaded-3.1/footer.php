
			<br class="clear">
		
		</section>
		<!-- /main content -->
		
		<!-- footer -->
		<footer>
			<p><strong>Wordpress</strong> powered by <a href="http://www.wordpress.org">Wordpress</a>. GTD/P2 Reloaded theme by <a href="#">WPVerse</a>.</p>
		</footer>
		<!-- /footer -->
	
	</div>
	<!-- /main wrapper -->

	<!-- keyboard shortcuts -->
	<div id="p2-the-keyboard-shortcuts">
		<dl>
			<dt>c</dt><dd>compose new post</dd>
			<dt>j</dt><dd>next post or comment</dd>
			<dt>k</dt><dd>previous post or comment</dd>
			<dt>r</dt><dd>reply</dd>
			<dt>e</dt><dd>edit</dd>
			<dt>o</dt><dd>show/hide comments</dd>
			<dt>t</dt><dd>go to top</dd>
			<dt>esc</dt><dd>cancel</dd>
		</dl>
	</div>
	<!-- /keyboard shortcuts -->

	<?php wp_footer() ?>

</body>
</html>